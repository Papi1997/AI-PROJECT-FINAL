# 💰 AI-Powered FinTech Personal Finance Manager

This project is a smart AI-powered personal finance manager that:

- 📈 Predicts future expenses using time series forecasting
- 💬 Offers financial planning advice powered by GPT-4
- 🏦 Integrates with (simulated) bank APIs and M-PESA (via Daraja)
- 🚨 Detects fraudulent transactions using anomaly detection
- 🖥️ Provides an interactive dashboard via Streamlit

---

## 📦 Features

- **Expense Forecasting**: Predicts spending patterns using Facebook Prophet
- **GPT-4 Advice**: Personalized financial guidance via OpenAI Chat API
- **Bank API Integration**: Simulated bank + M-PESA Daraja-ready code
- **Fraud Detection**: Detects anomalies in transactions
- **Streamlit Dashboard**: Clean UI for running and visualizing everything

---

## 🚀 Getting Started

### 1. Clone the repo
```bash
git clone https://github.com/Papi1997/AI-PROJECT-FINAL.git
cd AI-PROJECT-FINAL
```

### 2. Install dependencies
```bash
pip install -r requirements.txt
```

### 3. Set your OpenAI key
Edit the Python file and replace:
```python
openai.api_key = "your-secret-key"
```

### 4. Run the dashboard
```bash
streamlit run fintech_ai_manager.py
```

---

## 🔌 M-PESA Daraja API Integration (Pluggable)
Replace `fetch_bank_transactions()` with real API logic:
```python
import requests

def fetch_mpesa_transactions():
    url = "https://sandbox.safaricom.co.ke/mpesa/transactionstatus/v1/query"
    headers = {
        "Authorization": "Bearer ACCESS_TOKEN",
        "Content-Type": "application/json"
    }
    payload = { ... }
    response = requests.post(url, headers=headers, json=payload)
    return response.json()
```

Use your Paybill, consumer key/secret, and base64-encoded credentials.

---

## 📁 Project Structure
```
AI-PROJECT-FINAL/
├── fintech_ai_manager.py
├── requirements.txt
├── README.md
```

---

## 📜 License
MIT License - free to use and customize.
