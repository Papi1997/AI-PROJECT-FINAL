# AI-Powered FinTech Personal Finance Manager (with Dashboard UI)

# ========== Key Modules ==========
# 1. Expense Prediction (Time Series Forecasting)
# 2. GPT-based Financial Advice
# 3. Banking API Integration (Simulated + M-PESA Placeholder)
# 4. Fraud Detection (Anomaly Detection)
# 5. Streamlit Dashboard UI

# ---------- Module 1: Expense Prediction ----------
import pandas as pd
import numpy as np
from prophet import Prophet

def forecast_expenses(expense_data):
    df = pd.DataFrame(expense_data)
    df.columns = ['ds', 'y']
    model = Prophet()
    model.fit(df)
    future = model.make_future_dataframe(periods=30)
    forecast = model.predict(future)
    return forecast[['ds', 'yhat']]

# ---------- Module 2: GPT-based Financial Planner ----------
import openai

def gpt_financial_advice(user_context):
    openai.api_key = 'YOUR_API_KEY'
    prompt = f"""
    You are a smart financial assistant. A user has the following context:
    {user_context}
    Provide them with budgeting, saving, and investing advice.
    """
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "system", "content": "You are a helpful financial advisor."},
                  {"role": "user", "content": prompt}]
    )
    return response['choices'][0]['message']['content']

# ---------- Module 3: Simulated + M-PESA Bank API ----------
def fetch_bank_transactions(user_id):
    return [
        {"date": "2025-07-01", "amount": -1200, "desc": "Rent"},
        {"date": "2025-07-02", "amount": -150, "desc": "Groceries"},
        {"date": "2025-07-03", "amount": -50, "desc": "Transport"},
        {"date": "2025-07-05", "amount": 5000, "desc": "Salary"},
        {"date": "2025-07-06", "amount": -500, "desc": "Investments"},
    ]

# ---------- Module 4: Anomaly Detection for Fraud ----------
from sklearn.ensemble import IsolationForest

def detect_fraud(transactions):
    amounts = np.array([t['amount'] for t in transactions]).reshape(-1, 1)
    model = IsolationForest(contamination=0.1)
    model.fit(amounts)
    preds = model.predict(amounts)
    flagged = [transactions[i] for i, p in enumerate(preds) if p == -1]
    return flagged

# ---------- Module 5: Streamlit Dashboard UI ----------
import streamlit as st

def run_dashboard():
    st.title("💰 AI-Powered Personal Finance Manager")

    user_id = st.text_input("Enter your user ID", "user_1")
    context = st.text_area("Describe your financial situation:",
        "My monthly income is 5000. I spend heavily on rent and groceries. I want to save more.")

    if st.button("Analyze"):
        txns = fetch_bank_transactions(user_id)
        df_txns = pd.DataFrame(txns)

        forecast = forecast_expenses(
            [(t['date'], abs(t['amount'])) for t in txns if t['amount'] < 0]
        )
        advice = gpt_financial_advice(context)
        flagged = detect_fraud(txns)

        st.subheader("📈 Forecasted Expenses")
        st.line_chart(forecast.set_index('ds')['yhat'])

        st.subheader("💬 GPT Financial Advice")
        st.info(advice)

        st.subheader("🚨 Potential Fraudulent Transactions")
        if flagged:
            st.dataframe(pd.DataFrame(flagged))
        else:
            st.success("No suspicious transactions detected.")

# ---------- Run App ----------
if __name__ == '__main__':
    run_dashboard()
